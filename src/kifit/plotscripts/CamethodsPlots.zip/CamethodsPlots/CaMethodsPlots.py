# -*- coding: utf-8 -*-
"""
Created on Wed Jan 31 09:07:09 2024

@author: richte23
"""

from matplotlib import pyplot as plt
#from scipy import interpolate
import numpy as np
from matplotlib.ticker import ( LogLocator)


#import X coefs

X_Data = np.loadtxt('Ca+_X_Basis10spdf_final.txt')
m_X = X_Data[:,0]
XS = X_Data[:,1]
XD3 = X_Data[:,2]
XD5 = X_Data[:,3]
XP = X_Data[:,4]

XSD5 = XD5-XS
XSD3 = XD3-XS
XSP = XP-XS
XDfine = XD5-XD3


# F coefficients

F1P=-1.19*10**-6
F1D5 = -1.557*10**-6
F1D3 = -1.559*10**-6
# F1P=-1.18*10**-6
# F1D5 = -1.565*10**-6
# F1D3 = -1.567*10**-6
FDfine = F1D5-F1D3


#Agneses Data
#Agnese_Data_GKP=np.loadtxt('GKP_Yb_envelope.dat')
#Agnese_Data_NMGKP=np.loadtxt('NMGKP_Yb_envelope.dat')

#GKP_m=Agnese_Data_GKP[:,0]
#NMGKP_m=Agnese_Data_NMGKP[:,0]

#GKP=Agnese_Data_GKP[:,1]
#NMGKP=Agnese_Data_NMGKP[:,1]




plot1Data=np.loadtxt('CaMethodsPlot1Data.txt')
yeynD5P=plot1Data[:,0]
yeynD5Dfine=plot1Data[:,1]
yeynD5D3=plot1Data[:,2]
yeynD5P20=plot1Data[:,3]



plot2Data=np.loadtxt('CaMethodsPlot2Data.txt')

yeynD5DfineNL=plot2Data[:,0]

yeynD5DfineNLsigmaX=plot2Data[:,1]
yeyenDfine124expuncertainty=plot2Data[:,2]


alpha = 1/137 






###############################################################################################################################






fig, axs = plt.subplots(2, 1, figsize=(11.5, 17.5), dpi=100)  # Adjust figsize as needed
plt.rcParams.update({'font.size': 24})
plt.rcParams.update({'axes.linewidth': 1})


#axs[0].plot(m_X, abs(1/(F1D5*XDfine-FDfine*XSD5))/ (4 * np.pi * alpha), linewidth=10, alpha=0,label='$\\nu_1=\\nu_{729}$')
#axs[1].plot(m_X, abs(1/(F1D5*XDfine-FDfine*XSD5))/ (4 * np.pi * alpha), linewidth=10, alpha=0,label='$\\nu_1=\\nu_{729}$')

# First plot
axs[0].set_xlim(1,10**8)
axs[0].set_xscale('log')
axs[0].set_yscale('log')
axs[0].set_ylabel('$|1/(F_1 X_2-F_2 X_1)|$ $(\mathrm{eV}^{-2} \mathrm{fm}^{2})$', fontsize=24)
axs[0].set_xlabel('$m_\phi$ (eV/$c^2$)', fontsize=24)

axs[0].plot(m_X, abs(1/(F1D5*XDfine-FDfine*XSD5))/ (4 * np.pi * alpha), ls='-', c='red', label='$\\nu_2=\\nu_{\mathrm{DD}}$', linewidth=3)
axs[0].plot(m_X, abs(1/(F1D5*XSD3-F1D3*XSD5))/ (4 * np.pi * alpha),ls='--', c='blue', label='$\\nu_2=\\nu_{732}$ ', linewidth=3)
axs[0].plot(m_X, abs(1/(F1D5*XSP-F1P*XSD5))/ (4 * np.pi * alpha), ls=':', c='black', label='$\\nu_2=\\nu_{397}$', linewidth=3)
axs[0].legend(fontsize=24,loc='upper left', bbox_to_anchor=(-0.01, 0.97))

yticks = np.array([1e5,1e6,1e7, 1e8,1e9, 1e10,1e11, 1e12,1e13,1e14,1e15])
axs[0].set_yscale('log')

axs[0].set_yticks(yticks)
axs[0].set_yticklabels(['','$10^{6}$','','$10^{8}$','','$10^{10}$','','$10^{12}$','','$10^{14}$',''])
# Second plot

axs[1].set_xscale('log')
axs[1].set_yscale('log')
axs[1].set_ylabel('$|\\alpha_{\mathrm{NP}}/\\alpha_{\mathrm{EM}}|$', fontsize=24)
axs[1].set_xlabel('$m_\phi$ (eV/$c^2$)', fontsize=24)

axs[1].plot(m_X, np.array(yeynD5Dfine)/ (4 * np.pi * alpha), ls='-', c='red', label='$\\nu_2=\\nu_{\mathrm{DD}}$', linewidth=3)
axs[1].plot(m_X, np.array(yeynD5D3)/ (4 * np.pi * alpha),ls='--', c='blue', label='$\\nu_2=\\nu_{732}$ ', linewidth=3)
axs[1].plot(m_X, np.array(yeynD5P20)/ (4 * np.pi * alpha), ls=':', c='black', label='$\\nu_2=\\nu_{397}$ (20 Hz)', linewidth=3)
axs[1].plot(m_X, np.array(yeynD5P)/ (4 * np.pi * alpha), ls='-.', c='black', label='$\\nu_2=\\nu_{397}$ (80 kHz)', linewidth=3)
axs[1].legend(fontsize=24,loc='upper left', bbox_to_anchor=(-0.01, 0.97))

axs[1].set_xlim(1,10**8)
axs[1].set_ylim(3.01*10**-12,9.9*10**-3)
# Create a twin Axes sharing the same x-axis



yticks = np.array([1e-11,1e-10,1e-9,1e-8, 1e-7,1e-6, 1e-5,1e-4, 1e-3])
axs[1].set_yscale('log')

axs[1].set_yticks(yticks)
axs[1].set_yticklabels(['$10^{-11}$','','$10^{-9}$','','$10^{-7}$','','$10^{-5}$','','$10^{-3}$'])





axs2 = axs[1].twinx()



# Calculate and set y-axis ticks for y_e y_n / (4 * pi * alpha)
alpha = 1/137  # Fine structure constant
yticks = np.array([1e-12,1e-11,1e-10,1e-9, 1e-8,1e-7 ,1e-6,1e-5, 1e-4]) / (4 * np.pi * alpha)
axs2.set_yscale('log')
axs2.set_ylim(axs[1].get_ylim())
axs2.set_yticks(yticks)
axs2.set_yticklabels(['$10^{-12}$','','$10^{-10}$','','$10^{-8}$','','$10^{-6}$','','$10^{-4}$'])
axs2.set_ylabel('$|y_e y_n|/\hbar c$', fontsize=24)

# Adjust layout to prevent clipping of labels
xticks = np.array([1, 1e1,1e2,1e3, 1e4, 1e5,1e6,1e7,1e8])
axs[0].set_xscale('log')

axs[0].set_xticks(xticks)
axs[0].set_xticklabels(['$1$','','$10^{2}$','','$10^{4}$','','$10^{6}$','','$10^{8}$'])


xticks = np.array([1, 1e1,1e2,1e3, 1e4, 1e5,1e6,1e7,1e8])
axs[1].set_xscale('log')

axs[1].set_xticks(xticks)
axs[1].set_xticklabels(['$1$','','$10^{2}$','','$10^{4}$','','$10^{6}$','','$10^{8}$'])




plt.tight_layout()
axs[0].tick_params(axis='both', which='major', width=1.5, length=12)
axs[1].tick_params(axis='both', which='major', width=1.5, length=12)

axs2.tick_params(axis='both', which='major', width=1.5, length=12)

axs[0].tick_params(axis='both', which='minor', width=1, length=7)
axs[1].tick_params(axis='both', which='minor', width=1, length=7)

axs2.tick_params(axis='both', which='minor', width=1, length=7)


min_loc = LogLocator(subs='all', numticks=10000)

axs[1].xaxis.set_minor_locator(min_loc)
min_loc = LogLocator(subs='all', numticks=10000)
axs[0].xaxis.set_minor_locator(min_loc)

min_loc = LogLocator(subs='all', numticks=100)
axs[1].yaxis.set_minor_locator(min_loc)
min_loc = LogLocator(subs='all', numticks=100)
axs[0].yaxis.set_minor_locator(min_loc)

axs2.yaxis.set_minor_locator(LogLocator(subs='auto',base=10,numticks=1000))
fig.text(0.5, 0.485, '$\\nu_1=\\nu_{729}$', ha='center', va='center', fontsize=24,bbox=dict(boxstyle="round",fc=(1., 1, 1),ec=(0.1, 0.1, 0.1)))
fig.text(0.5, 0.975, '$\\nu_1=\\nu_{729}$', ha='center', va='center', fontsize=24,bbox=dict(boxstyle="round",fc=(1., 1, 1),ec=(0.1, 0.1, 0.1)))


fig.text(0.7, 0.1, 'linear mock data', ha='center', va='center', fontsize=24)

# Save the combined figure as a PDF
plt.savefig('ComparisonKPlinear_combined_plot.pdf')

plt.show()








#####################################################################################################################
















fig, axs = plt.subplots(1, 1, figsize=(11.5, 8.5), dpi=100)  # Adjust figsize as needed
plt.rcParams.update({'font.size': 24})
plt.rcParams.update({'axes.linewidth': 1})

# First plot
axs.set_xscale('log')
axs.set_yscale('log')
axs.set_ylabel('$|\\alpha_{\mathrm{NP}}/\\alpha_{\mathrm{EM}}|$', fontsize=24)
axs.set_xlabel('$m_\phi$ (eV/$c^2$)', fontsize=24)
#axs.plot(m_X, yeynD5Dfine2, ls='-', c='black', label='linear theory data', linewidth=3)
axs.plot(m_X, np.array(yeyenDfine124expuncertainty)/ (4 * np.pi * alpha), ls='-', c='red', label='linear mock data', linewidth=3)
axs.plot(m_X, np.array(yeynD5DfineNL)/ (4 * np.pi * alpha), ls='--', c='blue', label='experimental data $\sigma[X]=0$ ', linewidth=3)
axs.plot(m_X, np.array(yeynD5DfineNLsigmaX)/ (4 * np.pi * alpha), ls=':', c='black', label='experimental data $\sigma[X] > 0$', linewidth=3)
axs.legend(fontsize=24,loc='upper left', bbox_to_anchor=(-0.01, 0.97))

axs.set_xlim(1,10**8)
axs.set_ylim(1.0001*10**-10,9.999*10**-3)
# Create a twin Axes sharing the same x-axis

xticks = np.array([1, 1e1,1e2,1e3, 1e4, 1e5,1e6,1e7,1e8])
axs.set_xscale('log')

axs.set_xticks(xticks)
axs.set_xticklabels(['$1$','','$10^{2}$','','$10^{4}$','','$10^{6}$','','$10^{8}$'])

yticks = np.array([1e-9, 1e-8,1e-7,1e-6, 1e-5, 1e-4,1e-3])
axs.set_yscale('log')

axs.set_yticks(yticks)
axs.set_yticklabels(['$10^{-9}$','','$10^{-7}$','','$10^{-5}$','','$10^{-3}$'])

# Create a twin Axes sharing the same x-axis
axs2 = axs.twinx()

# Calculate and set y-axis ticks for y_e y_n / (4 * pi * alpha)
alpha = 1/137  # Fine structure constant
alpha = 1/137  # Fine structure constant
yticks = np.array([1e-10,1e-9, 1e-8,1e-7, 1e-6,1e-5, 1e-4]) / (4 * np.pi * alpha)
axs2.set_yscale('log')
axs2.set_ylim(axs.get_ylim())
axs2.set_yticks(yticks)
axs2.set_yticklabels(['$10^{-10}$','','$10^{-8}$','','$10^{-6}$','','$10^{-4}$'])
axs2.set_ylabel('$|y_e y_n|/\hbar c$', fontsize=24)

# Adjust layout to prevent clipping of labels
plt.tight_layout()
axs.tick_params(axis='both', which='major', width=1.5, length=12)
axs2.tick_params(axis='both', which='major', width=1.5, length=12)

axs.tick_params(axis='both', which='minor', width=1, length=7)
axs2.tick_params(axis='both', which='minor', width=1, length=7)
# Save the combined figure as a PDF


min_loc = LogLocator(subs='all', numticks=10)

fig.text(0.5, 0.952, '$\\nu_1=\\nu_{729}$, $\\nu_2=\\nu_{\mathrm{DD}}$', ha='center', va='center', fontsize=24,bbox=dict(boxstyle="round",fc=(1., 1, 1),ec=(0.1, 0.1, 0.1)))

axs.xaxis.set_minor_locator(min_loc)
#axs.yaxis.set_minor_locator(min_loc)
plt.savefig('ComparisonKPnonlinear_plot.pdf')
plt.show()








#####################################################################################################################################################












fig, axs = plt.subplots(1, 1, figsize=(11.5, 8.5), dpi=100)  # Adjust figsize as needed
plt.rcParams.update({'font.size': 24})
plt.rcParams.update({'axes.linewidth': 1})
alpha = 1/137
# First plot
axs.set_xlim(1,10**8)
axs.set_xscale('log')
xticks = np.array([1, 1e1,1e2,1e3, 1e4, 1e5,1e6,1e7,1e8])
axs.set_xscale('log')

axs.set_xticks(xticks)
axs.set_xticklabels(['$1$','','$10^{2}$','','$10^{4}$','','$10^{6}$','','$10^{8}$'])
#axs.set_yscale('log')
axs.set_ylabel('New physics coefficient $X$ (eV)', fontsize=24)
axs.set_xlabel('$m_\phi$ (eV/$c^2$)', fontsize=24)
#axs.plot(m_X, yeynD5Dfine2, ls='-', c='black', label='linear theory data', linewidth=3)
axs.plot(m_X, XSD5* (4 * np.pi * alpha), ls='-', c='red', label='$\\nu_{729}$', linewidth=3)
axs.plot(m_X, XSP* (4 * np.pi * alpha), ls='--', c='blue', label='$\\nu_{397}$ ', linewidth=3)
#axs.plot(m_X, yeynD5DfineNLsigmaX, ls=':', c='blue', label='experimental data $\sigma[X] > 0$', linewidth=3)
axs.legend(loc='upper right')


plt.tight_layout()

min_loc = LogLocator(subs='all', numticks=10)

axs.xaxis.set_minor_locator(min_loc)
# Adjust layout to prevent clipping of labels
plt.tight_layout()
axs.tick_params(axis='both', which='major', width=1.5, length=12)
axs2.tick_params(axis='both', which='major', width=1.5, length=12)

axs.tick_params(axis='both', which='minor', width=1, length=7)
axs2.tick_params(axis='both', which='minor', width=1, length=7)

# Save the combined figure as a PDF
plt.savefig('X_Ca+.pdf')

plt.show()





#############################################################################################################################################









mPhi = np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_1.dat', usecols=(0))


Yb24_GKP_AME20_X1=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_1.dat', usecols=(1))
Yb24_GKP_AME20_X2=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_2.dat', usecols=(1))
Yb24_GKP_AME20_X3=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_3.dat', usecols=(1))
Yb24_GKP_AME20_X4=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_4.dat', usecols=(1))
Yb24_GKP_AME20_X5=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_5.dat', usecols=(1))
Yb24_GKP_AME20_X6=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_6.dat', usecols=(1))
Yb24_GKP_AME20_X7=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_7.dat', usecols=(1))
Yb24_GKP_AME20_X8=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_8.dat', usecols=(1))
Yb24_GKP_AME20_X9=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_9.dat', usecols=(1))
Yb24_GKP_AME20_X10=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_10.dat', usecols=(1))
Yb24_GKP_AME20_Xenvelope=np.loadtxt('Yb24_GKP_AME20_X/Yb24_GKP_AME20_X_envelope.dat', usecols=(1))

Yb24_GKP_Door_X1=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_1.dat', usecols=(1))
Yb24_GKP_Door_X2=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_2.dat', usecols=(1))
Yb24_GKP_Door_X3=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_3.dat', usecols=(1))
Yb24_GKP_Door_X4=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_4.dat', usecols=(1))
Yb24_GKP_Door_X5=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_5.dat', usecols=(1))
Yb24_GKP_Door_X6=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_6.dat', usecols=(1))
Yb24_GKP_Door_X7=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_7.dat', usecols=(1))
Yb24_GKP_Door_X8=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_8.dat', usecols=(1))
Yb24_GKP_Door_X9=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_9.dat', usecols=(1))
Yb24_GKP_Door_X10=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_10.dat', usecols=(1))
Yb24_GKP_Door_Xenvelope=np.loadtxt('Yb24_GKP_Door_X/Yb24_GKP_Door_X_envelope.dat', usecols=(1))

Yb24_NMGKP_X1=np.loadtxt('Yb24_NMGKP_X/Yb24_NMGKP_X_1.dat', usecols=(1))
Yb24_NMGKP_X2=np.loadtxt('Yb24_NMGKP_X/Yb24_NMGKP_X_2.dat', usecols=(1))
Yb24_NMGKP_X3=np.loadtxt('Yb24_NMGKP_X/Yb24_NMGKP_X_3.dat', usecols=(1))
Yb24_NMGKP_X4=np.loadtxt('Yb24_NMGKP_X/Yb24_NMGKP_X_4.dat', usecols=(1))
Yb24_NMGKP_X5=np.loadtxt('Yb24_NMGKP_X/Yb24_NMGKP_X_5.dat', usecols=(1))
Yb24_NMGKP_Xenvelope=np.loadtxt('Yb24_NMGKP_X/Yb24_NMGKP_X_envelope.dat', usecols=(1))























fig, axs = plt.subplots(1, 1, figsize=(11.5, 8.5), dpi=100)  # Adjust figsize as needed
plt.rcParams.update({'font.size': 22})
plt.rcParams.update({'axes.linewidth': 1.5})

# First plot
axs.set_xscale('log')
axs.set_yscale('log')
axs.set_ylabel('$|\\alpha_{\mathrm{NP}}/\\alpha_{\mathrm{EM}}|$', fontsize=22, family='dejavuserif')
axs.set_xlabel('$m_\phi$ (eV/$c^2$)', fontsize=22, family='dejavuserif')


#axs.plot(m_X, yeynD5Dfine2, ls='-', c='black', label='linear theory data', linewidth=3)
# axs.plot(mPhi, Yb24_GKP_AME20_Xenvelope, ls='-', c='green', label='3D GKP (AME2020)', linewidth=4)
# axs.plot(mPhi, Yb24_GKP_AME20_X1, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X2, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X3, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X4, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X5, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X6, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X7, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X8, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X9, ls='-',c='green', linewidth=3,alpha=0.1)
# axs.plot(mPhi, Yb24_GKP_AME20_X10, ls='-',c='green', linewidth=3,alpha=0.1)




axs.plot(mPhi, Yb24_GKP_Door_Xenvelope, ls='-', c='blue', label='3D GKP (Door2024)', linewidth=4)
axs.plot(mPhi, Yb24_GKP_Door_X1, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X2, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X3, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X4, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X5, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X6, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X7, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X8, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X9, ls='-',c='blue', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_GKP_Door_X10, ls='-',c='blue', linewidth=3,alpha=0.1)




axs.plot(mPhi, Yb24_NMGKP_Xenvelope, ls='-', c='red', label='4D NMGKP ', linewidth=4)
axs.plot(mPhi, Yb24_NMGKP_X1, ls='-',c='red', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_NMGKP_X2, ls='-',c='red', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_NMGKP_X3, ls='-',c='red', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_NMGKP_X4, ls='-',c='red', linewidth=3,alpha=0.1)
axs.plot(mPhi, Yb24_NMGKP_X5, ls='-',c='red', linewidth=3,alpha=0.1)




axs.legend()





axs.set_xlim(1,10**8)
axs.set_ylim(2*10**-11,5*10**-3)
# Create a twin Axes sharing the same x-axis
xticks = np.array([1, 1e1,1e2,1e3, 1e4, 1e5,1e6,1e7,1e8])
axs.set_xscale('log')

axs.set_xticks(xticks)
axs.set_xticklabels(['$1$','','$10^{2}$','','$10^{4}$','','$10^{6}$','','$10^{8}$'])


yticks = np.array([1e-10,1e-9, 1e-8,1e-7, 1e-6,1e-5, 1e-4,1e-3])
axs.set_yscale('log')
axs.set_ylim(axs.get_ylim())
axs.set_yticks(yticks)
axs.set_yticklabels(['','$10^{-9}$','','$10^{-7}$','','$10^{-5}$','','$10^{-3}$'])

min_loc = LogLocator(subs='all', numticks=10)

axs.xaxis.set_minor_locator(min_loc)
#axs.yaxis.set_minor_locator(LogLocator(subs='all', numticks=1000))

axs2 = axs.twinx()

# Calculate and set y-axis ticks for y_e y_n / (4 * pi * alpha)
alpha = 1/137  # Fine structure constant
yticks = np.array([1e-11,1e-10,1e-9, 1e-8,1e-7, 1e-6,1e-5, 1e-4])/ (4 * np.pi * alpha)
axs2.set_yscale('log')
axs2.set_ylim(axs.get_ylim())
axs2.set_yticks(yticks)
axs2.set_yticklabels(['','$10^{-10}$','','$10^{-8}$','','$10^{-6}$','','$10^{-4}$'])
axs2.set_ylabel('$|y_e y_n|/\hbar c$', fontsize=24, family='dejavuserif')



# Adjust layout to prevent clipping of labels
plt.tight_layout()
axs.tick_params(axis='both', which='major', width=1.5, length=12)
axs2.tick_params(axis='both', which='major', width=1.5, length=12)

axs.tick_params(axis='both', which='minor', width=1, length=7)
axs2.tick_params(axis='both', which='minor', width=1, length=7)

# Save the combined figure as a PDF
plt.savefig('Yb_GKP_NMK_envelope.pdf')

plt.show()






